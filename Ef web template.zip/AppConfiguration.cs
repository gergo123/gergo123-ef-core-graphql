﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.Web
{
    public class AppConfiguration
    {
        public string corsOriginDomain { get; set; }
    }
}
