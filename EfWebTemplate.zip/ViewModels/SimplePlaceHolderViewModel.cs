﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.ViewModels
{
    public class SimplePlaceHolderViewModel
    {
        public int Id { get; set; }
        public string SimpleProperty { get; set; }

        public bool IsActive { get; set; }
    }
}
