﻿using EfTemplate1.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Threading.Tasks;

namespace $safeprojectname$.Controllers
{
    public interface IReactAdminController<T>
    {
        Task<ActionResult<IEnumerable<T>>> Get(string filter = "", string range = "", string sort = "");
        Task<ActionResult<T>> Get(long id);
        Task<IActionResult> PutAsync(long id, T entity);
        Task<ActionResult<T>> Post(T entity);
        Task<ActionResult<T>> Delete(long id);
    }

    [Route("api/[controller]")]
    [ApiController]
    public abstract class ReactAdminController<T> : ControllerBase, IReactAdminController<T> where T : class, new()
    {
        protected readonly CoreContext _context;
        protected DbSet<T> _table;
        /// <summary>
        /// Use this when you want to use this with conjuction with RLS repository
        /// </summary>
        public IQueryable<T> _tableQueryable;

        public ReactAdminController(CoreContext context)
        {
            _context = context;
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<T>> Delete(long id)
        {
            var entity = await _table.FindAsync(id);
            if (entity == null)
            {
                return NotFound();
            }

            _table.Remove(entity);
            await _context.SaveChangesAsync(new System.Threading.CancellationToken());

            return Ok(entity);
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<T>>> Get(string filter = "", string range = "", string sort = "")
        {
            var entityQuery = _tableQueryable == null ? _table.AsQueryable() : _tableQueryable;

            if (!string.IsNullOrEmpty(filter))
            {
                var filterVal = (JObject)JsonConvert.DeserializeObject(filter);
                var t = new T();
                foreach (var f in filterVal)
                {
                    if (f.Value.Type == JTokenType.Array)
                    {
                        var mappedFilter = new List<string>();
                        var predicate = "";
                        foreach (var filterValue in f.Value)
                        {
                            if (predicate == string.Empty)
                            {
                                predicate += $"{f.Key} == {filterValue.ToString()}";
                            }
                            else
                            {
                                predicate += $"|| {f.Key} == {filterValue.ToString()}";
                            }
                        }
                        entityQuery = entityQuery.Where(predicate);
                    }
                    else
                    {
                        // Autocomplete sends the char q with search value, not property name so have to be specific here...
                        var type = t.GetType();
                        if (type.Name == "SecurityIdentity" && f.Key == "q")
                        {
                            entityQuery = entityQuery.Where($"FullName.Contains(@0)", f.Value.ToString());
                        }
                        else
                        {
                            if (type.GetProperty(f.Key).PropertyType == typeof(string))
                            {
                                entityQuery = entityQuery.Where($"{f.Key}.Contains(@0)", f.Value.ToString());
                            }
                            else
                            {
                                entityQuery = entityQuery.Where($"{f.Key} == @0", f.Value.ToString());
                            }
                        }
                    }
                }
            }
            var count = entityQuery.Count();

            if (!string.IsNullOrEmpty(sort))
            {
                var sortVal = JsonConvert.DeserializeObject<List<string>>(sort);
                var condition = sortVal.First();
                var order = sortVal.Last() == "ASC" ? "" : "descending";
                entityQuery = entityQuery.OrderBy($"{condition} {order}");
            }

            var from = 0;
            var to = 0;
            if (!string.IsNullOrEmpty(range))
            {
                var rangeVal = JsonConvert.DeserializeObject<List<int>>(range);
                from = rangeVal.First();
                to = rangeVal.Last();
                entityQuery = entityQuery.Skip(from).Take(to - from + 1);
            }
            Response.Headers.Add("Access-Control-Expose-Headers", "Content-Range");
            Response.Headers.Add("Content-Range", $"{typeof(T).Name.ToLower()} {from}-{to}/{count}");

            return await entityQuery.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<T>> Get(long id)
        {
            var entity = await _table.FindAsync(id);

            if (entity == null)
            {
                return NotFound();
            }

            return entity;
        }

        [HttpPost]
        public async Task<ActionResult<T>> Post(T entity)
        {
            _table.Add(entity);
            await _context.SaveChangesAsync(new System.Threading.CancellationToken());
            var id = typeof(T).GetProperty("Id").GetValue(entity);
            return Ok(await _table.FindAsync(id));
        }

        [HttpPut("{id}")]
        public virtual async Task<IActionResult> PutAsync(long id, T entity)
        {
            var entityId = (long)typeof(T).GetProperty("Id").GetValue(entity);
            if (id != entityId)
            {
                return BadRequest();
            }

            _context.Entry(entity).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync(new System.Threading.CancellationToken());
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EntityExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Ok(await _table.FindAsync(entityId));
        }

        private bool EntityExists(long id)
        {
            return _table.Any(e => (long)typeof(T).GetProperty("Id").GetValue(e) == id);
        }
    }
}
