﻿using $safeprojectname$.Stepper.Model.Workflow;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Interfaces.Stepper
{
    public interface IValidateTasks<K>
        where K : TaskEntity
    {
        void AlterTasks(K task);
    }
}
