﻿using $safeprojectname$.Model.RLS;
using $safeprojectname$.RLS;
using $safeprojectname$.Stepper.Model;
using $safeprojectname$.Stepper.Model.Workflow;

namespace $safeprojectname$.Stepper.StateChanges
{
    public class OneToTwoChange : StateChange<TestEntityModel, TestEntityStates>
    {
        private CurrentUserProvider currentUserProvider { get; }
        public OneToTwoChange(CurrentUserProvider currentUserProvider) : base()
        {
            this.currentUserProvider = currentUserProvider;
        }

        public override StateChangeConfiguration GetConfiguration()
        {
            return new StateChangeConfiguration
            {
                AllowedEndStates = new System.Enum[]
                {
                    TestEntityStates.SecondPlace
                },
                HasPermissionToFullfillChange = new Model.RLS.SecurityObject[]
                {
                    new SecurityIdentity { Id = currentUserProvider.Identity.Id }
                }
            };
        }

        public void additionalLogic()
        {
            //throw new NotImplementedException();
        }
    }
}
