﻿using $safeprojectname$.Model.RLS;
using $safeprojectname$.Repositories.GeneralRepository.Stepper;
using $safeprojectname$.RLS;
using $safeprojectname$.Stepper.Model;
using $safeprojectname$.Stepper.Model.Workflow;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Stepper.StateChanges
{
    public class ThreeToFourChange : StateChangeHasTackPrerequityState<TestEntityModel, TestEntityStates>
    {
        public CurrentUserProvider CurrentUserProvider { get; }

        public ThreeToFourChange(IBasicTaskRepository taskSecureStore, CurrentUserProvider currentUserProvider) :
            base(taskSecureStore)
        {
            CurrentUserProvider = currentUserProvider;
        }

        public override StateChangeConfiguration GetConfiguration()
        {
            return new StateChangeConfiguration
            {
                AllowedEndStates = new Enum[]
                {
                    TestEntityStates.FourthPlace
                },
                HasPermissionToFullfillChange = new Model.RLS.SecurityObject[]
                {
                    new SecurityIdentity { Id = CurrentUserProvider.Identity.Id },
                }
            };
        }
    }
}
