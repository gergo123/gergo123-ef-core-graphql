﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Stepper.ViewModel
{
    public class FourToFiveVM
    {
        public bool FailChange { get; set; }
    }
}
