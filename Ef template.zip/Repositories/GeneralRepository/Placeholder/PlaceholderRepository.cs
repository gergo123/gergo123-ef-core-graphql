using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using $safeprojectname$.Model.Placeholder;
using $safeprojectname$.Model;

namespace $safeprojectname$.Repositories
{
    public class PlaceholderRepository : Interfaces.Repositories.Repository<PlaceholderEntity>, IPlaceholderRepository
{
        private Model.CoreContext Context;
        public PlaceholderRepository(CoreContext context): base (context)
        {
        }
    }

    public interface IPlaceholderRepository : Interfaces.Repositories.IEntityRepository<PlaceholderEntity>
    {
    }
}