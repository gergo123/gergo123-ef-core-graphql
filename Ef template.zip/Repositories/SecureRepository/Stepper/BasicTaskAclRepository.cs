﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using $safeprojectname$.Stepper.Model.Workflow;
using Microsoft.EntityFrameworkCore;
using $safeprojectname$.Model;

namespace $safeprojectname$.Repositories.SecureRepository.Stepper
{
    public class BasicTaskAclRepository : Interfaces.Repositories.Repository<BasicTaskAcl>, IBasicTaskAclRepository
    {
        private Model.CoreContext Context;
        public BasicTaskAclRepository(CoreContext context) : base(context)
        {
            {
            }
        }
    }

    public interface IBasicTaskAclRepository : Interfaces.Repositories.IEntityRepository<BasicTaskAcl>
    {
    }
}